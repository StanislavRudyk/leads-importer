"""Initial T3 Production Migration

Revision ID: 314159265359
Revises: 
Create Date: 2026-03-29 05:05:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '314159265359'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # 1. Create leads table
    op.create_table(
        'leads',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('phone', sa.String(length=100), nullable=True),
        sa.Column('phones', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('first_name', sa.String(length=255), nullable=True),
        sa.Column('last_name', sa.String(length=255), nullable=True),
        sa.Column('country_iso2', sa.String(length=10), nullable=True),
        sa.Column('nationality', sa.String(length=255), nullable=True),
        sa.Column('city', sa.String(length=255), nullable=True),
        sa.Column('state', sa.String(length=10), nullable=True),
        sa.Column('language', sa.String(length=100), nullable=True),
        sa.Column('source', sa.String(length=255), nullable=True),
        sa.Column('latest_source', sa.String(length=255), nullable=True),
        sa.Column('latest_campaign', sa.String(length=255), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True),
        sa.Column('is_buyer', sa.Boolean(), nullable=True),
        sa.Column('tags', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('meta_info', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('brevo_id', sa.String(length=100), nullable=True),
        sa.Column('file_created_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('import_count', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_leads_email', 'leads', ['email'], unique=True)
    op.create_index('ix_leads_city', 'leads', ['city'], unique=False)
    op.create_index('ix_leads_country', 'leads', ['country_iso2'], unique=False)
    op.create_index('ix_leads_source', 'leads', ['source'], unique=False)
    op.create_index('ix_leads_status', 'leads', ['status'], unique=False)
    op.create_index('ix_leads_created_at', 'leads', ['created_at'], unique=False)
    op.execute("CREATE INDEX IF NOT EXISTS ix_leads_metadata_gin ON leads USING gin (meta_info)")

    # 2. Create import_logs table
    op.create_table(
        'import_logs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('filename', sa.Text(), nullable=False),
        sa.Column('source', sa.String(length=255), nullable=True),
        sa.Column('rows_total', sa.Integer(), nullable=True),
        sa.Column('rows_inserted', sa.Integer(), nullable=True),
        sa.Column('rows_updated', sa.Integer(), nullable=True),
        sa.Column('rows_skipped', sa.Integer(), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True),
        sa.Column('error_details', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('imported_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

def downgrade():
    op.drop_table('import_logs')
    op.drop_table('leads')
