import asyncio
import os
import time
import logging
from datetime import datetime, timezone
from src.parser import parse_file_bulk
from src.db import upsert_leads_batch, AsyncSessionLocal


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("mass_import_audit.log", encoding="utf-8")
    ]
)
logger = logging.getLogger("mass_import")

IMPORT_DIR = "Mailchimp"
CONCURRENCY_LIMIT = 10   
SEMAPHORE = asyncio.Semaphore(CONCURRENCY_LIMIT)

async def process_one_file(file_path: str, stats: dict):
    """Parses and upserts a single file with detailed logging."""
    async with SEMAPHORE:
        start_time = time.time()
        try:

            leads = await parse_file_bulk(file_path)
            if not leads:
                logger.warning(f"EMPTY: {file_path} - No valid personal leads found.")
                stats["empty_files"] += 1
                return

            batch_size = 500
            total_added = 0
            total_updated = 0
            source_name = os.path.basename(file_path)
            
            async with AsyncSessionLocal() as session:
                for i in range(0, len(leads), batch_size):
                    batch = leads[i : i + batch_size]
                    added, updated, skipped = await upsert_leads_batch(session, batch, source_name)
                    total_added += added
                    total_updated += updated
                await session.commit()
                
            elapsed = time.time() - start_time
            logger.info(f"DONE: {file_path} | +{total_added} New | ~{total_updated} Upd | {len(leads)} Total | {elapsed:.2f}s")
            
            stats["total_leads_added"] += total_added
            stats["total_leads_updated"] += total_updated
            stats["successful_files"] += 1
            
        except Exception as e:
            logger.error(f"ERROR: {file_path} - {str(e)}")
            stats["failed_files"] += 1

async def run_mass_import():
    """Traverses the import directory and triggers parallel processing."""
    if not os.path.exists(IMPORT_DIR):
        logger.error(f"Directory {IMPORT_DIR} not found!")
        return

    logger.info(f"Starting IDEAL MASS IMPORT from {IMPORT_DIR}...")
    
    tasks = []
    stats = {
        "successful_files": 0,
        "failed_files": 0,
        "empty_files": 0,
        "total_leads_added": 0,
        "total_leads_updated": 0
    }

   
    blacklist_keywords = {
        "non persian", "10,000 contacts", "test", "raw", "database", 
        "crm", "industry", "organization", "service", "directory", 
        "business", "companies", "professional", "publications"
    }
    
    for root, _, files in os.walk(IMPORT_DIR):
        for file in files:
            fname_lower = file.lower()
            if fname_lower.endswith(('.csv', '.xlsx', '.xls')):

                has_junk_kw = any(kw in fname_lower for kw in blacklist_keywords)
                if has_junk_kw:
                    logger.warning(f"SKIPPING BLACKLISTED JUNK: {file}")
                    continue
                file_path = os.path.join(root, file)
                tasks.append(process_one_file(file_path, stats))

    logger.info(f"Queued {len(tasks)} files for processing.")
    
    await asyncio.gather(*tasks)


    logger.info("=" * 50)
    logger.info("MASS IMPORT COMPLETE")
    logger.info(f"Files Processed: {stats['successful_files']}")
    logger.info(f"Empty/Junk Files: {stats['empty_files']}")
    logger.info(f"Failed Files: {stats['failed_files']}")
    logger.info(f"Total NEW Unique Leads: {stats['total_leads_added']}")
    logger.info(f"Total UPDATED Identifies: {stats['total_leads_updated']}")
    logger.info("=" * 50)
    

    async with AsyncSessionLocal() as session:
        from sqlalchemy import text
        res = await session.execute(text("SELECT count(*) FROM leads"))
        count = res.scalar()
        logger.info(f"FINAL DATABASE LEAD COUNT: {count}")
        if 40000 <= count <= 60000:
            logger.info("SUCCESS: Lead count is within the IDEAL TARGET range (~50k).")
        else:
            logger.warning(f"CAUTION: Lead count {count} is outside expected range!")

if __name__ == "__main__":
    asyncio.run(run_mass_import())
