import logging
import os
import shutil
import time
import psutil
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Union
import jwt
import pandas as pd
from fastapi import (
    BackgroundTasks, Depends, FastAPI, File,
    HTTPException, Query, UploadFile, status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from pydantic import BaseModel
from sqlalchemy import select, func, text
from .config import settings
from .db import AsyncSessionLocal, Lead, ImportLog, upsert_leads_batch, create_import_log
from .normalizer import (
    normalize_city, normalize_country, normalize_email,
    normalize_nationality, normalize_phone,
)
from .metabase import router as metabase_router

REGION_MAP = {
    'US': 'USA', 'CA': 'Canada', 'AU': 'Oceania', 'NZ': 'Oceania',
    'GB': 'Europe', 'IE': 'Europe', 'FR': 'Europe', 'DE': 'Europe',
    'IT': 'Europe', 'ES': 'Europe', 'PT': 'Europe', 'NL': 'Europe',
    'BE': 'Europe', 'AT': 'Europe', 'CH': 'Europe', 'SE': 'Europe',
    'NO': 'Europe', 'DK': 'Europe', 'FI': 'Europe', 'PL': 'Europe',
    'CZ': 'Europe', 'HU': 'Europe', 'RO': 'Europe', 'GR': 'Europe',
    'TR': 'Europe', 'IS': 'Europe', 'HR': 'Europe', 'RS': 'Europe',
    'SI': 'Europe', 'BG': 'Europe', 'MK': 'Europe', 'AL': 'Europe',
    'MT': 'Europe', 'LV': 'Europe', 'LT': 'Europe', 'EE': 'Europe',
    'AE': 'Middle East', 'SA': 'Middle East', 'QA': 'Middle East',
    'BH': 'Middle East', 'OM': 'Middle East', 'KW': 'Middle East',
    'IL': 'Middle East', 'JO': 'Middle East', 'LB': 'Middle East',
    'IR': 'Middle East', 'IQ': 'Middle East', 'EG': 'Middle East',
    'JP': 'Asia', 'KR': 'Asia', 'CN': 'Asia', 'HK': 'Asia',
    'TW': 'Asia', 'SG': 'Asia', 'TH': 'Asia', 'MY': 'Asia',
    'ID': 'Asia', 'PH': 'Asia', 'VN': 'Asia', 'IN': 'Asia',
    'PK': 'Asia', 'BD': 'Asia', 'LK': 'Asia', 'MN': 'Asia',
    'ZA': 'Africa', 'NG': 'Africa', 'KE': 'Africa', 'MA': 'Africa',
    'EG': 'Africa', 'GH': 'Africa', 'ET': 'Africa',
    'BR': 'South America', 'AR': 'South America', 'CO': 'South America',
    'PE': 'South America', 'CL': 'South America', 'MX': 'South America',
    'RU': 'Russia/CIS', 'UA': 'Russia/CIS', 'BY': 'Russia/CIS',
    'KZ': 'Russia/CIS', 'GE': 'Russia/CIS', 'AM': 'Russia/CIS',
    'AZ': 'Russia/CIS',
}

logger = logging.getLogger('leads_importer.api')
if not logger.handlers:
    logger.addHandler(logging.StreamHandler())

app = FastAPI(title='Leads Importer API', version='2.0.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*'],
)
app.include_router(metabase_router)

from fastapi import Header

api_key_query = APIKeyHeader(name='API-Key', auto_error=False)
x_api_key_query = APIKeyHeader(name='X-API-Key', auto_error=False)
API_KEY = os.getenv('API_KEY')

async def get_api_key(
    api_key: Optional[str] = Depends(api_key_query),
    x_api_key: Optional[str] = Depends(x_api_key_query)
):
    provided_key = api_key or x_api_key
    if provided_key != API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Invalid API Key',
        )

class LeadSchema(BaseModel):
    email: str
    phone: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    country: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    is_buyer: bool = False
    tags: List[str] = []
    metadata: dict = {}

    class Config:
        extra = 'allow'

@app.get('/health')
async def health():
    return {'status': 'ok', 'version': '2.0.0'}

@app.post('/api/v1/import/upload')
async def upload_leads(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    source_name: str = Query(None),
    api_key: str = Depends(get_api_key),
):
    filename = os.path.basename(file.filename or 'upload.csv')
    from tempfile import gettempdir
    clean_name = os.path.basename(file.filename)
    tmp_path = os.path.join(gettempdir(), clean_name)
    MAX_SIZE = 100 * 1024 * 1024
    file_size = 0
    try:
        file.file.seek(0, 2)
        file_size = file.file.tell()
        file.file.seek(0)
    except: pass
    if file_size > MAX_SIZE:
        raise HTTPException(status_code=413, detail=f'File too large. Max 100 MB.')
    try:
        with open(tmp_path, 'wb') as buffer:
            shutil.copyfileobj(file.file, buffer)
        from .parser import _read_dataframe
        df_peek = _read_dataframe(tmp_path)
        row_count = len(df_peek) if df_peek is not None else 0
        SYNC_THRESHOLD = 50000
        from .cli import run_import
        if row_count < SYNC_THRESHOLD:
            stats = await run_import(tmp_path, source_name or filename, notify=True)
            if os.path.exists(tmp_path): os.remove(tmp_path)
            return {
                "import_id": stats.get("import_id"), "rows_total": stats.get("rows_total", 0),
                "rows_inserted": stats.get("rows_inserted", 0), "rows_updated": stats.get("rows_updated", 0),
                "rows_skipped": stats.get("rows_skipped", 0), "status": stats.get("status", "success")
            }
        else:
            task_id = f"job_{int(time.time())}"
            background_tasks.add_task(_run_and_clean, tmp_path, source_name or filename, task_id)
            return {"status": "processing", "job_id": task_id, "message": f"Processing {row_count} rows in background."}
    except Exception as e:
        logger.error(f'Upload error: {e}')
        if os.path.exists(tmp_path): os.remove(tmp_path)
        raise HTTPException(status_code=500, detail=str(e))

import asyncio
import traceback
IMPORT_SEMAPHORE = asyncio.Semaphore(50)
_active_tasks = {}

@app.get('/api/v1/import/active')
async def get_active_imports():
    tasks = []
    for tid, tinfo in _active_tasks.items():
        tasks.append({
            "task_id": tid, "filename": tinfo["filename"], "status": tinfo["status"],
            "error": tinfo.get("error"), "queued_at": tinfo["queued_at"],
            "rows_total": tinfo.get("rows_total", 0),
            "rows_inserted": tinfo.get("rows_inserted", 0), "rows_updated": tinfo.get("rows_updated", 0),
            "rows_skipped": tinfo.get("rows_skipped", 0),
            "phase": tinfo.get("phase", ""),
        })
    return {"tasks": tasks, "count": len(tasks)}

def _cleanup_old_tasks():
    global _active_tasks
    if len(_active_tasks) > 100:
        keys = [k for k, v in _active_tasks.items() if v["status"] in ("done", "failed", "empty", "partial", "success")]
        for k in keys[:50]: _active_tasks.pop(k, None)

async def _run_and_clean(file_path: str, source_name: str, task_id: Optional[str] = None):
    global _active_tasks
    _cleanup_old_tasks()
    tid = task_id or f"task_{int(time.time() * 1000)}"
    _active_tasks[tid] = {"filename": os.path.basename(source_name), "status": "waiting", "queued_at": datetime.now(timezone.utc).isoformat(), "rows_total": 0, "rows_inserted": 0, "rows_updated": 0, "rows_skipped": 0, "phase": "queued"}
    async def on_progress(inserted, updated, skipped, phase="saving", total=0):
        if tid in _active_tasks:
            _active_tasks[tid].update({"rows_inserted": inserted, "rows_updated": updated, "rows_skipped": skipped, "phase": phase, "rows_total": total})
    try:
        from .cli import run_import
        async with IMPORT_SEMAPHORE:
            _active_tasks[tid]["status"] = "running"
            _active_tasks[tid]["phase"] = "parsing"
            stats = await run_import(file_path, source_name, on_progress=on_progress)
            if stats:
                _active_tasks[tid].update({
                    "rows_total": stats.get("rows_total", 0),
                    "rows_inserted": stats.get("rows_inserted", 0),
                    "rows_updated": stats.get("rows_updated", 0),
                    "rows_skipped": stats.get("rows_skipped", 0),
                    "status": "done", "phase": "complete"
                })
    except Exception as exc:
        logger.error(f'Background import failed for {source_name}:\n{traceback.format_exc()}')
        _active_tasks[tid].update({"status": "failed", "error": str(exc), "phase": "error"})
    finally:
        if os.path.exists(file_path):
            try: os.remove(file_path)
            except: pass

@app.post('/api/v1/notify/weekly-digest')
async def trigger_weekly_digest(api_key: str = Depends(get_api_key)):
    from .notifier import notifier
    await notifier.send_weekly_digest()
    return {'status': 'success'}

@app.get('/api/v1/dashboard/metrics')
async def get_dashboard_metrics():
    async with AsyncSessionLocal() as session:
        q = text("SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days') as leads_7d, COUNT(*) FILTER (WHERE status = 'done') as completed FROM leads")
        res = (await session.execute(q)).fetchone()
        return {
            'totalLeads': res.total or 0, 'leads7d': res.leads_7d or 0, 'markets': 0, 
            'completed': res.completed or 0, 'upcoming': (res.total or 0) - (res.completed or 0),
        }

@app.get('/api/v1/dashboard/system-status')
async def get_system_status():
    async with AsyncSessionLocal() as session:
        t_files = (await session.execute(select(func.count()).select_from(ImportLog))).scalar() or 0
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        f_today = (await session.execute(select(func.count()).select_from(ImportLog).where(ImportLog.imported_at >= today))).scalar() or 0
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory()
        dsk = shutil.disk_usage("/")
        return {
            'cpu_percent': cpu, 'ram_percent': mem.percent, 'disk_percent': round((dsk.used / dsk.total) * 100, 1),
            'files_total': t_files, 'files_today': f_today, 'status': 'healthy' if cpu < 90 else 'stressed'
        }

@app.get('/api/v1/dashboard/overview')
async def get_dashboard_overview(search: Optional[str] = Query(None), region: Optional[str] = Query('all')):
    async with AsyncSessionLocal() as session:
        where, params = [], {}
        if search and len(search.strip()) >= 2:
            s_val = f"%{search.strip().lower()}%"
            where.append("(LOWER(city) LIKE :s OR LOWER(email) LIKE :s OR LOWER(first_name) LIKE :s OR LOWER(last_name) LIKE :s)")
            params['s'] = s_val
        if region != 'all':
            countries = [k for k, v in REGION_MAP.items() if v == region]
            if countries:
                where.append("country_iso2 IN :countries")
                params['countries'] = tuple(countries)
        where_str = f"WHERE {' AND '.join(where)}" if where else ""
        q = text(f"SELECT COALESCE(NULLIF(TRIM(city), ''), 'Unknown') as city, MAX(country_iso2) as country_iso2, MAX(state) as state, COUNT(*) as leads, COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days') as leads_7d, CASE WHEN SUM(CASE WHEN status != 'done' THEN 1 ELSE 0 END) > 0 THEN 'upcoming' ELSE 'done' END as calculated_status FROM leads {where_str} GROUP BY COALESCE(NULLIF(TRIM(city), ''), 'Unknown') ORDER BY leads DESC LIMIT 100")
        rows = (await session.execute(q, params)).fetchall()
        data = []
        for idx, r in enumerate(rows):
            country = r.country_iso2 or 'XX'
            data.append({
                'id': idx, 'city': r.city or 'Unknown', 'country': country, 'state': r.state or '',
                'region': REGION_MAP.get(country.upper(), 'Other'), 'leads': r.leads,
                'leads_7d': r.leads_7d or 0, 'status': r.calculated_status,
            })
        return data

@app.get('/api/v1/dashboard/sources')
async def get_dashboard_sources():
    async with AsyncSessionLocal() as session:
        q = text("SELECT COALESCE(latest_source, source, 'Unknown') as src, COUNT(id) as total, COUNT(id) FILTER (WHERE is_buyer = TRUE) as buyers, COUNT(id) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days') as new_7d FROM leads GROUP BY src ORDER BY total DESC")
        rows = (await session.execute(q)).fetchall()
        data = []
        for idx, r in enumerate(rows):
            conversion = round(r.buyers / r.total * 100, 2) if r.total > 0 else 0
            data.append({
                'id': idx, 'source': r.src or 'Unknown', 'total_leads': r.total,
                'new_leads_7d': r.new_7d or 0, 'buyers': r.buyers, 'conversion': conversion,
            })
        return data

@app.get('/api/v1/dashboard/imports')
async def get_dashboard_imports():
    async with AsyncSessionLocal() as session:
        q = text("SELECT id, filename, source, rows_total, rows_inserted, rows_updated, rows_skipped, status, imported_at FROM import_logs ORDER BY imported_at DESC LIMIT 100")
        rows = (await session.execute(q)).fetchall()
        return [{
            'id': r.id, 'filename': r.filename, 'source': r.source, 'total_rows': r.rows_total,
            'inserted': r.rows_inserted, 'updated': r.rows_updated, 'skipped': r.rows_skipped,
            'status': r.status, 'created_at': r.imported_at.strftime('%Y-%m-%d %H:%M:%S') if r.imported_at else ''
        } for r in rows]
