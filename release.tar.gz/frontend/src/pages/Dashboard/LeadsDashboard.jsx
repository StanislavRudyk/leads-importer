import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Chart as ChartJS, CategoryScale, LinearScale,
  BarElement, ArcElement, Title, Tooltip, Legend
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend);

const RC = { 'USA': '#3b82f6', 'Europe': '#8b5cf6', 'Oceania': '#10b981', 'Asia': '#f59e0b', 'Middle East': '#ef4444', 'Canada': '#22d3ee', 'Other': '#6b7280' };
const API_KEY = "gmp79b9qSN}&JWX";

function fmt(n) { return n == null ? '—' : Number(n).toLocaleString('en'); }

// Base API URL configuration
const API_BASE = '';

const availableTabs = [
  { id: 15, title: 'Overview' },
  { id: 16, title: 'Campaigns' },
  { id: 17, title: 'System & Imports' },
];

const LeadsDashboard = () => {
  const navigate = useNavigate();
  const [userRole, setUserRole] = useState('admin');
  const [activeTab, setActiveTab] = useState(15);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [message, setMessage] = useState(null);
  const [activeTasks, setActiveTasks] = useState([]);
  const [activeCount, setActiveCount] = useState(0);
  const [showQueue, setShowQueue] = useState(false);
  const folderInputRef = React.useRef(null);
  const fileInputRef = React.useRef(null);

  const [data, setData] = useState([]);
  const [search, setSearch] = useState('');
  const [fReg, setFReg] = useState('all');
  const [viewMode, setViewMode] = useState('city');

  const [campaignData, setCampaignData] = useState([]);
  const [importData, setImportData] = useState([]);
  const [tab1Metrics, setTab1Metrics] = useState({ totalLeads: 0, leads7d: 0, completed: 0, markets: 0, upcoming: 0 });

  const fetchData = useCallback(async (isBackground = false) => {
    if (!isBackground) setLoading(true);
    try {
      // 1. Fetch main metrics (required for UI summary)
      try {
        const msR = await fetch(`${API_BASE}/api/v1/dashboard/metrics`);
        if (msR.ok) {
          setTab1Metrics(await msR.json());
        } else {
          // Fallback to empty metrics to allow UI to render
          if (!tab1Metrics) setTab1Metrics({ totalLeads: 0, leads7d: 0, completed: 0 });
        }
      } catch (e) {
        console.error("Metrics fetch error:", e);
        if (!tab1Metrics) setTab1Metrics({ totalLeads: 0, leads7d: 0, completed: 0 });
      }

      // 2. Fetch active tasks
      try {
        const activeR = await fetch(`${API_BASE}/api/v1/import/active`);
        if (activeR.ok) {
          const activeD = await activeR.json();
           const rawTasks = activeD.tasks || [];
           setActiveTasks(rawTasks);
           // Show waiting, running, and failed tasks in the queue display
           const pendingCount = rawTasks.filter(t => ["running", "waiting", "queued", "failed"].includes(t.status)).length;
           setActiveCount(pendingCount);
        }
      } catch (e) {
        console.error("Active tasks fetch error:", e);
      }

      // 3. Tab-specific data
      if (activeTab === 15) {
        let url = `${API_BASE}/api/v1/dashboard/overview?`;
        if (search && search.length >= 2) url += `search=${encodeURIComponent(search)}&`;
        if (fReg !== 'all') url += `region=${encodeURIComponent(fReg)}&`;
        
        const r = await fetch(url);
        if (r.ok) {
            const d = await r.json();
            setData(Array.isArray(d) ? d : []);
        }
      } else if (activeTab === 16) {
        const r = await fetch(`${API_BASE}/api/v1/dashboard/sources`);
        if (r.ok) {
            const d = await r.json();
            setCampaignData(Array.isArray(d) ? d : []);
        }
      } else if (activeTab === 17) {
        const r = await fetch(`${API_BASE}/api/v1/dashboard/imports`);
        if (r.ok) {
            const d = await r.json();
            setImportData(Array.isArray(d) ? d : []);
        }
      }
    } catch (e) {
      console.error("Fetch error:", e);
      if (message === null) {
          setMessage({ text: "Server connection issue. Retrying...", type: "error" });
      }
    } finally {
      if (!isBackground) setLoading(false);
    }
  }, [activeTab, search, fReg]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => fetchData(true), 5000);
    
    // Safety timeout: ensure loading screen disappears after 3s even if API blocks
    const safety = setTimeout(() => setLoading(false), 3000);
    
    return () => {
      clearInterval(interval);
      clearTimeout(safety);
    };
  }, [fetchData]);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImporting(true);
    setMessage({ text: "Uploading file...", type: "info" });

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch(`${API_BASE}/api/v1/import/upload?source_name=${encodeURIComponent(file.name)}`, {
        method: "POST",
        headers: { "API-Key": API_KEY },
        body: formData
      });
      if (res.ok) {
        setMessage({ text: "Upload successful. Processing in background.", type: "success" });
        fetchData(true); // check queue immediately
      } else {
        const result = await res.json();
        setMessage({ text: `Error: ${result.detail || "Upload failed"}`, type: "error" });
      }
    } catch (err) {
      setMessage({ text: "Network error during upload.", type: "error" });
    } finally {
      setImporting(false);
      setTimeout(() => setMessage(null), 5000);
    }
  };


  const handleFolderUpload = async (e) => {
    const rawFiles = e.target.files;
    if (!rawFiles || rawFiles.length === 0) return;
    
    const files = Array.from(rawFiles).filter(f => !f.name.startsWith('.'));
    if (!files.length) return;

    // Sort files by size ascending (smallest first)
    files.sort((a, b) => a.size - b.size);

    setImporting(true);
    let successCount = 0;
    let errorCount = 0;
    let completed = 0;
    const concurrencyLimit = 50;
    const serverCapacityLimit = 50;

    const waitForServerCapacity = async () => {
        let currentActive = 100; // Assume full until checked
        while (currentActive >= serverCapacityLimit) {
            currentActive = await fetchData(true); // Silent re-fetch
            if (currentActive >= serverCapacityLimit) {
                // Wait 1.5s before checking again if server is busy
                await new Promise(r => setTimeout(r, 1500));
            }
        }
    };

    const processFile = async (file) => {
        await waitForServerCapacity();
        
        const formData = new FormData();
        formData.append("file", file);
        const sourcePath = file.webkitRelativePath || file.name;

        try {
            const res = await fetch(`${API_BASE}/api/v1/import/upload?source_name=${encodeURIComponent(sourcePath)}`, {
                method: "POST",
                headers: { "API-Key": API_KEY },
                body: formData
            });
            if (res.ok) successCount++;
            else errorCount++;
        } catch (err) {
            errorCount++;
        }
        completed++;
        setMessage({ text: `Uploading... ${completed} of ${files.length} files processed`, type: "info" });
    };

    setMessage({ text: `Starting parallel upload of ${files.length} files...`, type: "info" });
    
    // Execute pool with thundering herd prevention
    const queue = [...files];
    const workers = Array(Math.min(concurrencyLimit, queue.length)).fill(null).map(async () => {
        while (queue.length > 0) {
            const nextFile = queue.shift();
            if (nextFile) {
                await processFile(nextFile);
                // Throttling to prevent slamming the server
                await new Promise(r => setTimeout(r, 100)); 
            }
        }
    });

    await Promise.all(workers);
    
    setMessage({ text: `Folder upload complete. ${successCount} successful, ${errorCount} failed.`, type: successCount > 0 ? "success" : "error" });
    setImporting(false);
    if (e.target) e.target.value = '';
    setTimeout(() => setMessage(null), 10000);
  };

  const filteredData = useMemo(() => {
    let res = [...data];
    if (search) res = res.filter(d => (d.city||'').toLowerCase().includes(search.toLowerCase()) || (d.country||'').toLowerCase().includes(search.toLowerCase()) || d.region.toLowerCase().includes(search.toLowerCase()));
    if (fReg !== 'all') res = res.filter(d => d.region === fReg);
    return res;
  }, [data, search, fReg]);

  const aggregatedData = useMemo(() => {
    if (viewMode === 'city') return filteredData.map(d => ({ ...d, label: `${d.city} / ${d.country}` })).sort((a,b) => b.leads - a.leads);
    const grouped = {};
    filteredData.forEach(d => {
      const cCode = d.country || "XX";
      if (!grouped[cCode]) grouped[cCode] = { id: cCode, label: cCode, country: cCode, region: d.region, leads: 0, leads_7d: 0, status: 'upcoming', cities: 0 };
      grouped[cCode].leads += (d.leads || 0);
      grouped[cCode].leads_7d += (d.leads_7d || 0);
      grouped[cCode].cities += 1;
      if (d.status === 'done') grouped[cCode].status = 'done';
    });
    return Object.values(grouped).sort((a,b) => b.leads - a.leads);
  }, [filteredData, viewMode]);

  const tab1Stats = useMemo(() => {
    const tL = tab1Metrics ? tab1Metrics.totalLeads : aggregatedData.reduce((s, d) => s + (d.leads || 0), 0);
    const t7 = tab1Metrics ? tab1Metrics.leads7d : aggregatedData.reduce((s, d) => s + (d.leads_7d || 0), 0);
    const doneC = tab1Metrics ? tab1Metrics.completed : aggregatedData.filter(d => d.status === 'done').length;
    return { tL, t7, doneC, m: aggregatedData.length, rawCities: filteredData.length };
  }, [aggregatedData, filteredData, tab1Metrics]);

  const barChartData = useMemo(() => {
    const top = aggregatedData.slice(0, 15);
    return {
      labels: top.map(d => d.label),
      datasets: [{
        data: top.map(d => d.leads),
        backgroundColor: top.map(d => (RC[d.region] || '#6b7280') + 'b3'),
        borderRadius: 4,
        borderWidth: 0
      }]
    };
  }, [aggregatedData]);

  const pieDataObj = useMemo(() => {
    const map = {};
    aggregatedData.forEach(d => { map[d.region] = (map[d.region] || 0) + (d.leads || 0); });
    const entries = Object.entries(map).sort((a,b)=>b[1]-a[1]);
    return {
      labels: entries.map(kv => kv[0]),
      entries,
      total: entries.reduce((s, kv) => s + kv[1], 0),
      datasets: [{
        data: entries.map(kv => kv[1]),
        backgroundColor: entries.map(kv => RC[kv[0]] || '#6b7280'),
        borderWidth: 2, borderColor: '#0d0f12'
      }]
    };
  }, [aggregatedData]);

  const renderTab1 = () => (
    <>
      <div className="metrics">
        <div className="mc a"><div className="mlb">Total Leads</div><div className="mv">{fmt(tab1Stats.tL)}</div><div className="ms">all markets</div></div>
        <div className="mc am"><div className="mlb">+7d Leads</div><div className="mv">{tab1Stats.t7>0?'+':''}{fmt(tab1Stats.t7)}</div><div className="ms">last 7 days</div></div>
        <div className="mc"><div className="mlb">Datapoints</div><div className="mv">{viewMode==='city'?tab1Stats.m:tab1Stats.m+' / '+tab1Stats.rawCities}</div><div className="ms">{viewMode==='city'?'unique cities':'countries / cities'}</div></div>
        <div className="mc g"><div className="mlb">Completed</div><div className="mv">{tab1Stats.doneC}</div><div className="ms">status: done</div></div>
        <div className="mc"><div className="mlb">Upcoming</div><div className="mv">{fmt(tab1Stats.tL - tab1Stats.doneC)}</div><div className="ms">status: new</div></div>
      </div>


      <div className="charts-row">
        <div className="cc" style={{flex: 2}}>
          <div className="ct">Leads by {viewMode === 'city' ? 'Market' : 'Country'} — Top 15</div>
          <div style={{position:'relative', height: Math.max(200, Math.min(15, aggregatedData.length)*32+40)}}>
            <Bar options={{ indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { color: 'rgba(255,255,255,.05)' }, ticks: { color: '#9ca3af', font: {size: 11} } }, y: { grid: { display: false }, ticks: { color: '#e5e7eb', font: {size: 11} } } } }} data={barChartData} />
          </div>
        </div>
        <div className="cc" style={{flex: 1}}>
          <div className="ct">Performance by Region</div>
          <div style={{position:'relative', height:'180px'}}><Doughnut options={{ responsive: true, maintainAspectRatio: false, cutout: '65%', plugins: { legend: { display: false } } }} data={pieDataObj} /></div>
          <div className="pie-legend" style={{marginTop:'15px', display:'flex', flexDirection:'column', gap:'8px'}}>
            {pieDataObj.entries.slice(0, 5).map(([r,v]) => (
              <div key={r} style={{display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:'12px'}}><div style={{display:'flex', alignItems:'center', gap:'8px'}}><div style={{width:'10px', height:'10px', borderRadius:'50%', background:RC[r]||'#6b7280'}}></div><span style={{color:'#d1d5db'}}>{r}</span></div><div style={{display:'flex', alignItems:'center', gap:'12px'}}><span style={{color:'#9ca3af', fontFamily:'var(--mo)'}}>{fmt(v)}</span><span style={{color:'#6b7280', fontFamily:'var(--mo)', width:'30px', textAlign:'right'}}>{pieDataObj.total>0?Math.round(v/pieDataObj.total*100):0}%</span></div></div>
            ))}
          </div>
        </div>
      </div>
      <div className="tcard">
        <div className="thr"><div className="tt">Global Leads Database</div></div>
        <div className="tscroll">
          <table>
            <thead><tr><th style={{width: '30%'}}>{viewMode === 'city' ? 'City & Country' : 'Country'}</th><th style={{width: '20%'}}>Region</th><th style={{textAlign: 'right'}}>Total Leads</th><th style={{textAlign: 'right', color: '#34d399'}}>+7d New</th><th style={{textAlign: 'center'}}>Market Share</th><th style={{textAlign: 'center'}}>Status</th></tr></thead>
            <tbody>
              {aggregatedData.map(d => { const pct = tab1Stats.tL>0 ? Math.round((d.leads||0)/tab1Stats.tL*100) : 0; return (<tr key={d.id}><td style={{fontWeight: 500, color: '#e5e7eb'}}>{d.label}{viewMode === 'country' && <span style={{marginLeft:'8px', fontSize:'11px', color:'#9ca3af'}}>({d.cities} cities)</span>}</td><td><span style={{color: RC[d.region]||'#9ca3af', fontSize:'11px', padding:'2px 8px', background:'rgba(255,255,255,0.05)', borderRadius:'4px'}}>{d.region}</span></td><td style={{fontFamily:'var(--mo)', fontWeight:600, textAlign: 'right', color: '#f3f4f6'}}>{fmt(d.leads)}</td><td style={{fontFamily:'var(--mo)', textAlign: 'right', color: '#34d399'}}>{d.leads_7d > 0 ? `+${fmt(d.leads_7d)}` : '—'}</td><td><div className="bcel" style={{justifyContent: 'center'}}><div className="bbg"><div className="bfill" style={{width:`${Math.min(100, Math.max(2, (d.leads||0)/Math.max(1, aggregatedData[0]?.leads||1)*100))}%`, background:RC[d.region]||'#6b7280'}}></div></div><span className="bpct">{pct}%</span></div></td><td style={{textAlign: 'center'}}><span className={`spill ${d.status==="done"?'done':'upcoming'}`}>{d.status==="done" ? "✓ Done" : "○ Active"}</span></td></tr>); })}
            </tbody>
          </table>
          {aggregatedData.length === 0 && <div className="empty">No data points present.</div>}
        </div>
      </div>
    </>
  );

  const renderTab2 = () => {
    const sortedC = [...campaignData].sort((a,b)=>b.total_leads-a.total_leads);
    const topCol = ['#3b82f6','#8b5cf6','#ec4899','#f59e0b','#10b981'];
    return (
      <>
        <div className="charts-row"><div className="cc" style={{flex: 1}}><div className="ct">Top Traffic Sources</div><div style={{position:'relative', height: '280px'}}><Bar options={{ indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { color: 'rgba(255,255,255,.05)' }, ticks: { color: '#9ca3af' } }, y: { grid: { display: false }, ticks: { color: '#e5e7eb', font: {size: 11} } } } }} data={{ labels: sortedC.slice(0, 10).map(d => d.source.length > 20 ? d.source.slice(0,18)+'...' : d.source), datasets: [{ data: sortedC.slice(0, 10).map(d => d.total_leads), backgroundColor: sortedC.slice(0, 10).map((_, i) => topCol[i%topCol.length]), borderRadius: 4 }] }} /></div></div></div>
        <div className="tcard">
          <div className="thr"><div className="tt">Campaigns Pipeline</div></div>
          <div className="tscroll">
            <table>
              <thead><tr><th style={{width: '40%'}}>Traffic Source</th><th style={{textAlign: 'right'}}>Total Leads (Volume)</th><th style={{textAlign: 'right', color:'#34d399'}}>New (7d)</th><th style={{textAlign: 'right'}}>Qualified Buyers</th><th style={{textAlign: 'center'}}>Conv. Rate</th></tr></thead>
              <tbody>
                {sortedC.map((d, i) => (<tr key={d.id}><td><strong style={{color:'#e5e7eb', fontWeight: 500}}>{d.source}</strong>{i < 3 && <span style={{marginLeft:'10px', fontSize:'9px', padding:'2px 4px', background:'#3b82f633', color:'#60a5fa', borderRadius:'4px'}}>TOP {i+1}</span>}</td><td style={{fontFamily:'var(--mo)', textAlign: 'right', fontWeight: 600}}>{fmt(d.total_leads)}</td><td style={{fontFamily:'var(--mo)', color:'#34d399', textAlign: 'right'}}>{d.new_leads_7d > 0 ? `+${fmt(d.new_leads_7d)}` : '—'}</td><td style={{fontFamily:'var(--mo)', textAlign: 'right', color: d.buyers > 0 ? '#fcd34d' : '#9ca3af'}}>{fmt(d.buyers)}</td><td style={{textAlign: 'center'}}><span style={{fontFamily:'var(--mo)', fontWeight: 600, color: d.conversion >= 2 ? '#a78bfa' : '#6b7280', fontSize:'13px'}}>{d.conversion}%</span></td></tr>))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  };

  const renderTab3 = () => (
    <div className="tcard">
      <div className="thr"><div className="tt">Systems & Import Logistics</div></div>
      <div className="tscroll">
        <table>
          <thead><tr><th>Log #</th><th>Timestamp</th><th>Import Context</th><th style={{textAlign: 'right'}}>Total Scan</th><th style={{textAlign: 'right', color:'#34d399'}}>Inserted (+New)</th><th style={{textAlign: 'right', color:'#fbbf24'}}>Updated (Merge)</th><th style={{textAlign: 'right', color:'#ef4444'}}>Skipped (Dups/Err)</th></tr></thead>
          <tbody>
            {importData.length === 0 ? <tr><td colSpan="7" className="empty">No import activity logged yet.</td></tr> : importData.map(d => {
              const rowStatus = d.status === 'error' ? 'failed' : (d.status === 'skipped' ? 'skipped' : 'success');
              const statusColor = { 'success': '#34d399', 'skipped': '#94a3b8', 'failed': '#ef4444' }[rowStatus];
              return (
                <tr key={d.id} style={{ opacity: rowStatus === 'skipped' ? 0.7 : 1 }}>
                  <td style={{fontFamily:'var(--mo)', color:'#9ca3af', fontSize:'11px'}}>#{String(d.id).padStart(4, '0')}</td>
                  <td style={{fontFamily:'var(--mo)', fontSize:'12px', color:'#d1d5db'}}>{d.created_at}</td>
                  <td>
                    <div style={{color:'#e5e7eb', fontWeight:500}}>{d.filename}</div>
                    <div style={{color:'#6b7280', fontSize:'11px', marginTop:'2px'}}>Via: {d.source}</div>
                  </td>
                  <td style={{fontFamily:'var(--mo)', textAlign: 'right', color:'#f3f4f6'}}>{fmt(d.total_rows)}</td>
                  <td style={{fontFamily:'var(--mo)', color:'#34d399', textAlign: 'right', fontWeight: d.inserted > 0 ? 600 : 400}}>{fmt(d.inserted)}</td>
                  <td style={{fontFamily:'var(--mo)', color:'#fbbf24', textAlign: 'right', fontWeight: d.updated > 0 ? 600 : 400}}>{fmt(d.updated)}</td>
                  <td style={{fontFamily:'var(--mo)', color: statusColor, textAlign: 'right', fontWeight: d.skipped > 0 ? 600 : 400}}>
                    {fmt(d.skipped)}
                    {rowStatus === 'skipped' && <span style={{fontSize:'9px', marginLeft:'5px'}}>(SYNCHRONIZED)</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <div className="topbar">
        <div className="logo"><b style={{color: '#fff'}}>LEADS IMPORTER</b> <span style={{color: '#6b7280'}}>• Analytics Core</span></div>
        <div className="hacts">
          {activeCount > 0 && (
            <div className="active-queue" style={{ position: 'relative', marginRight: '20px' }}>
              <button 
                onClick={() => setShowQueue(!showQueue)}
                style={{ background: '#1e293b', border: '1px solid #334155', color: activeTasks.some(t=>t.status==='failed') ? '#ef4444' : '#60a5fa', padding: '5px 12px', borderRadius: '4px', cursor: 'pointer', fontSize: '12px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '8px' }}
              >
                <span style={{ width: '8px', height: '8px', background: activeTasks.some(t=>t.status==='failed') ? '#ef4444' : '#3b82f6', borderRadius: '50%', animation: 'pulse 1.5s infinite' }}></span>
                {activeTasks.some(t=>t.status==='failed') ? 'Import Issues' : (() => {
                  const running = activeTasks.filter(t => t.status === 'running');
                  if (running.length > 0) {
                    const r = running[0];
                    const phase = r.phase || 'processing';
                    if (phase === 'parsing') return `Parsing ${r.filename}...`;
                    if (phase === 'saving' && r.rows_total > 0) return `Saving ${fmt(r.rows_inserted + r.rows_updated)}/${fmt(r.rows_total)}`;
                    return `Processing ${activeCount} ${activeCount === 1 ? 'file' : 'files'}`;
                  }
                  return `Queued: ${activeCount} ${activeCount === 1 ? 'file' : 'files'}`;
                })()}
              </button>
              {showQueue && (
                <div className="queue-dropdown" style={{ position: 'absolute', top: '100%', right: 0, marginTop: '8px', background: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px', padding: '12px', width: '340px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)', zIndex: 100 }}>
                  <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Server Queue</div>
                  <div style={{ maxHeight: '300px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    {activeTasks.map(t => {
                      const pct = t.rows_total > 0 ? Math.min(100, Math.round((t.rows_inserted + t.rows_updated) / t.rows_total * 100)) : 0;
                      const phaseLabel = { parsing: '📄 Parsing file...', parsed: '✅ Parsed', saving: `💾 Saving rows...`, complete: '✅ Complete', error: '❌ Error', queued: '⏳ Queued' }[t.phase] || t.phase;
                      return (
                      <div key={t.task_id} style={{ display: 'flex', flexDirection: 'column', gap: '3px', padding: '8px', background: t.status === 'failed' ? '#ef444411' : t.status === 'done' ? '#10b98111' : '#1e293b66', borderRadius: '6px', border: t.status === 'failed' ? '1px solid #ef444433' : t.status === 'done' ? '1px solid #10b98133' : '1px solid #1e293b' }}>
                        <div style={{ color: t.status === 'failed' ? '#fca5a5' : '#e2e8f0', fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 500 }}>{t.filename}</div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ color: t.status === 'running' ? '#60a5fa' : (t.status === 'failed' ? '#ef4444' : t.status === 'done' ? '#34d399' : '#94a3b8'), fontSize: '10px', fontWeight: 600 }}>{phaseLabel}</span>
                          {t.rows_total > 0 && <span style={{ color: '#94a3b8', fontSize: '10px', fontFamily: 'var(--mo)' }}>{fmt(t.rows_total)} rows</span>}
                        </div>
                        {t.status === 'running' && t.rows_total > 0 && (
                          <div style={{ marginTop: '3px' }}>
                            <div style={{ height: '4px', background: '#1e293b', borderRadius: '2px', overflow: 'hidden' }}>
                              <div style={{ height: '100%', width: `${pct}%`, background: 'linear-gradient(90deg, #3b82f6, #60a5fa)', borderRadius: '2px', transition: 'width 0.3s ease' }}></div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '3px', fontSize: '10px' }}>
                              <div style={{ display: 'flex', gap: '8px' }}>
                                <span style={{ color: '#34d399' }}>+{fmt(t.rows_inserted)} new</span>
                                <span style={{ color: '#fbbf24' }}>~{fmt(t.rows_updated)} upd</span>
                                {t.rows_skipped > 0 && <span style={{ color: '#94a3b8' }}>{fmt(t.rows_skipped)} skip</span>}
                              </div>
                              <span style={{ color: '#60a5fa', fontWeight: 600, fontFamily: 'var(--mo)' }}>{pct}%</span>
                            </div>
                          </div>
                        )}
                        {t.status === 'done' && (
                          <div style={{ display: 'flex', gap: '8px', marginTop: '2px', fontSize: '10px' }}>
                            <span style={{ color: '#34d399' }}>+{fmt(t.rows_inserted)} new</span>
                            <span style={{ color: '#fbbf24' }}>~{fmt(t.rows_updated)} upd</span>
                            <span style={{ color: '#94a3b8' }}>{fmt(t.rows_skipped)} skip</span>
                          </div>
                        )}
                        {t.error && <div style={{ color: '#ef4444', fontSize: '9px', marginTop: '2px', fontStyle: 'italic' }}>Error: {t.error}</div>}
                      </div>
                    );})}
                  </div>
                </div>
              )}
            </div>
          )}
          {message && <span style={{marginRight:'15px', fontSize:'12px', color: message.type==='error'?'#ef4444':'#add6ff', cursor: 'pointer'}} onClick={() => { setImporting(false); setMessage(null); }}>{message.text} ✕</span>}
          <button className="ref-btn" onClick={fetchData} style={{background:'transparent', border:'1px solid #374151', color:'#9ca3af', padding:'5px 12px', borderRadius:'4px', marginRight:'10px', cursor:'pointer'}}>↻ Refresh</button>
          
          {userRole === 'admin' && (
            <>
              <button 
                className="ulbl" 
                onClick={() => folderInputRef.current?.click()} 
                disabled={importing}
                style={{background:'#10b981', color:'#fff', padding:'5px 15px', border:'none', borderRadius:'4px', cursor: importing ? 'not-allowed' : 'pointer', fontSize:'13px', fontWeight:600, marginRight:'10px'}}
              >
                {importing ? "Processing..." : "Import Folder"}
              </button>
              <input 
                type="file" 
                ref={folderInputRef}
                webkitdirectory="true" 
                directory="true" 
                multiple 
                onChange={handleFolderUpload} 
                style={{display:'none'}} 
              />

              <button 
                className="ulbl" 
                onClick={() => fileInputRef.current?.click()} 
                disabled={importing}
                style={{background:'#3b82f6', color:'#fff', padding:'5px 15px', border:'none', borderRadius:'4px', cursor: importing ? 'not-allowed' : 'pointer', fontSize:'13px', fontWeight:600}}
              >
                {importing ? "Processing..." : "Import CSV"}
              </button>
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileUpload} 
                style={{display:'none'}} 
              />
            </>
          )}
        </div>
      </div>
      <div className="page" style={{ display: 'flex', flex: 1 }}>
        <div className="sidebar">
          <div>
            <div className="sl">Main Menu</div>
            <div style={{display:'flex', flexDirection:'column', gap:'5px', marginTop:'10px'}}>
              <button className="fbtn active" style={{justifyContent: 'flex-start', borderLeft: '3px solid #3b82f6'}}>
                <span className="rdot" style={{marginRight:'8px'}}></span>Overview
              </button>
              <button className="fbtn" onClick={() => navigate('/analytics')} style={{justifyContent: 'flex-start', borderLeft: '3px solid transparent'}}>
                <span className="rdot" style={{marginRight:'8px'}}></span>BI Analytics
              </button>
            </div>
          </div>
          <div className="dvd"></div>
          <div><div className="sl">Dashboards</div><div style={{display:'flex', flexDirection:'column', gap:'5px', marginTop:'10px'}}>{availableTabs.filter(tab => {
            if (userRole === 'viewer') return tab.id === 15;
            if (userRole === 'manager') return tab.id !== 17;
            return true;
          }).map(tab => (<button key={tab.id} className={`fbtn ${activeTab === tab.id ? 'active' : ''}`} onClick={() => setActiveTab(tab.id)} style={{justifyContent: 'flex-start', borderLeft: activeTab===tab.id?'3px solid #3b82f6':'3px solid transparent'}}><span className="rdot" style={{background: activeTab === tab.id ? '#3b82f6' : '#4b5563', marginRight:'8px'}}></span>{tab.title}</button>))}</div></div>
          <div className="dvd"></div>
          <div><div className="sl">Session Role</div><select value={userRole} onChange={e => {
            const newRole = e.target.value;
            setUserRole(newRole);
            if (newRole === 'viewer' && activeTab !== 15) setActiveTab(15);
            if (newRole === 'manager' && activeTab === 17) setActiveTab(15);
          }} style={{width: '100%', marginTop:'8px', background: '#111827', color: '#e5e7eb', border: '1px solid #374151', padding: '8px', borderRadius: '6px', cursor: 'pointer', fontFamily:'var(--fn)'}}><option value="admin">Administrator (All Access)</option><option value="manager">Manager (No Imports)</option><option value="viewer">Viewer (Overview Only)</option></select></div>
          {activeTab === 15 && (<><div className="dvd"></div><div><div className="sl" style={{marginBottom:'10px'}}>Data Granularity</div><div style={{display:'flex', gap:'5px', background:'#111827', border:'1px solid #374151', borderRadius:'6px', padding:'4px', overflow:'hidden'}}><button onClick={() => setViewMode('country')} style={{flex: 1, padding:'6px', background: viewMode==='country'?'#3b82f6':'transparent', border:'none', color:viewMode==='country'?'#fff':'#9ca3af', borderRadius:'4px', cursor:'pointer', fontFamily:'var(--fn)', fontSize:'12px', fontWeight:viewMode==='country'?600:400}}>by Country</button><button onClick={() => setViewMode('city')} style={{flex: 1, padding:'6px', background: viewMode==='city'?'#3b82f6':'transparent', border:'none', color:viewMode==='city'?'#fff':'#9ca3af', borderRadius:'4px', cursor:'pointer', fontFamily:'var(--fn)', fontSize:'12px', fontWeight:viewMode==='city'?600:400}}>by City</button></div></div><div className="dvd"></div><div><div className="sl" style={{marginBottom:'10px'}}>Search Filter</div><input type="text" placeholder="Search city, email, name..." value={search} onChange={e=>setSearch(e.target.value)} style={{width:'100%', background:'#111827', border:'1px solid #374151', borderRadius:'6px', padding:'8px 12px', color:'#f3f4f6', fontFamily:'var(--fn)', fontSize:'12px'}} /></div></>)}
          <div className="dvd"></div>
          {userRole === 'admin' && (
            <div className="sidebar-footer">
              <div className="sl">System Link</div>
              <a href="/nocodb/" target="_blank" rel="noreferrer" className="fbtn" style={{textDecoration:'none'}}>
                <span className="rdot" style={{marginRight:'8px', background:'#10b981'}}></span>NocoDB Tables
              </a>
            </div>
          )}
        </div>
        <div className="content">
          {activeTab === 15 && renderTab1()}
          {activeTab === 16 && renderTab2()}
          {activeTab === 17 && renderTab3()}
          {loading && <div style={{position:'fixed', bottom:'20px', right:'20px', background:'#1e293b', padding:'8px 15px', borderRadius:'20px', fontSize:'11px', color:'#60a5fa', border:'1px solid #334155', zIndex: 1000}}>Updating Data...</div>}
        </div>
      </div>
    </div>
  );
};

export default LeadsDashboard;
